# Service Plan: Campaign Orchestrator and Agent Runtime

## Responsibility
Plan, estimate, and execute campaign workflows using separate agents that call merchant capability services via x402.

## Agents
- News Agent: calls CNN News merchant.
- Image Agent: calls Midjourney Image merchant.
- Ads Agent: calls Google Adverts merchant.

## Workflow
1. Receive user campaign intent from Business CLI.
2. Create activity record.
3. Ask merchants for price discovery or perform preflight calls.
4. Produce estimate and buffer suggestion.
5. Wait for passkey-approved budget mandate.
6. Execute agents in order:
   - News Agent retrieves news/context.
   - Image Agent creates campaign visual.
   - Ads Agent launches simulated ad campaign.
7. Stop if remaining budget cannot satisfy new x402 challenge.
8. Return final cost summary.

## APIs

```http
POST /activities
POST /activities/{activityId}/estimate
POST /activities/{activityId}/execute
GET /activities/{activityId}
GET /activities/{activityId}/cost-summary
```

## Events Produced
- `activity.created`
- `activity.estimate.created`
- `merchant.capability.delivered`

## Acceptance Criteria
- Handles extra Midjourney payment challenge only if inside approved threshold.
- Rejects extra challenge if it would exceed approved budget.
- Returns final consumer cost.
