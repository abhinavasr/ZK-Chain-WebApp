# Service Plan: Payment Orchestration Service and x402 Handling

## Responsibility
Act as the policy and signing layer between business agents and x402-protected merchant APIs.

## Flow
1. Agent calls merchant endpoint.
2. Merchant returns HTTP `402 Payment Required` with challenge.
3. Payment Orchestration Service validates challenge.
4. Service checks mandate, approved merchant, approved capability, nonce, expiry, and remaining budget.
5. Service creates payment assertion.
6. Agent retries merchant call with assertion.
7. Merchant returns result.
8. Service records spend against activity.

## APIs

```http
POST /x402/handle-challenge
POST /x402/assertions
GET /activities/{activityId}/spend
GET /activities/{activityId}/remaining-budget
```

## Validation
- Reject expired challenge.
- Reject unknown merchant.
- Reject capability not allowed by mandate.
- Reject duplicate nonce.
- Reject if challenge amount exceeds remaining approved budget.
- Bind assertion to exact challenge ID, nonce, merchant, capability, and activity.

## Acceptance Criteria
- CNN `$0.10`, Midjourney `$0.50`, Google Adverts `$0.02` are paid in sequence.
- Extra challenge is only paid if total remains under budget.
- Every assertion creates an auditable event.
