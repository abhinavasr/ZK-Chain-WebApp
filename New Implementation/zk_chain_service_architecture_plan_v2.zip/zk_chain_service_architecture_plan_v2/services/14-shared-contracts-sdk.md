# Service Plan: Shared Contracts and SDK Packages

## Responsibility
Provide shared TypeScript packages without collapsing services into a monolith.

## Packages
- `api-contracts`: REST DTOs and OpenAPI specs.
- `event-contracts`: event schemas and validators.
- `x402-client`: challenge handling and assertion attachment.
- `x402-server`: merchant middleware for 402 challenge issuance and assertion verification.
- `ap2-mandates`: mandate schema, signing, verification helpers.
- `zk-commitments`: commitment hashing, salt generation, nullifier derivation.
- `ui-theme-tokens`: Mastercard/Adyen/Accenture-inspired theme tokens.

## Rule
Packages can contain shared types and libraries only. They must not contain business process orchestration that belongs to services.

## Acceptance Criteria
- Merchant services use `x402-server`.
- Business agents use `x402-client`.
- Mandate service uses `ap2-mandates`.
- Commitment ledger uses `zk-commitments`.
