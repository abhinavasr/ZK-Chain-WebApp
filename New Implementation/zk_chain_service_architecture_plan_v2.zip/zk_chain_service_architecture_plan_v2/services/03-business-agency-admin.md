# Service Plan: Marketing Agency / Business Admin Portal

## Responsibility
Show business users, passkeys, campaign requests, estimates, mandates, agent runs, merchant calls, and final consumer cost.

## Theme
Accenture-inspired: dark/white/purple enterprise theme. Do not use protected logos unless allowed.

## Screens
- Dashboard
- Business Users
- Passkey Registrations
- Campaign Requests
- Estimate vs Actual Cost
- Mandate Evidence
- Agent Runs
- Merchant Calls
- Final Consumer Cost

## APIs Consumed
- Business Auth Service
- Campaign Orchestrator Service
- Mandate Evidence Service
- Payment Orchestration Service
- Observability/Event Query Service

## Events Displayed
- `business.auth.otp.verified`
- `business.auth.passkey.registered`
- `activity.estimate.created`
- `mandate.budget.signed`
- `x402.challenge.received`
- `x402.payment.asserted`
- `merchant.capability.delivered`

## Acceptance Criteria
- User can see estimate `$0.62`, suggested budget `$0.75`, actual spend, and remaining budget.
- User can inspect which merchant capability calls were made.
- User can see mandate hashes and passkey approval status.
