# Service Plan: Mastercard Admin Portal and Funding Service

## Responsibility
Create and monitor fixed Mastercard funding envelopes allocated to PSPs. Mastercard controls only the top-level program envelope and does not directly fund individual businesses.

## Key Requirements
- Mastercard can allocate a fixed envelope to a PSP, e.g. `$1,000,000`.
- The envelope limit remains fixed regardless of how many businesses PSP funds.
- Store private envelope amount in Mastercard Funding Service DB.
- Publish only commitment hash to smart contract.
- Show PSP utilization and remaining headroom.

## APIs

```http
POST /psp-envelopes
GET /psp-envelopes
GET /psp-envelopes/{programId}
GET /psp-envelopes/{programId}/utilization
```

## Events Produced
- `funding.mastercard.envelope.created`
- `contract.status.changed`

## Portal Screens
- Create PSP Envelope
- PSP Envelope List
- Envelope Utilization
- Contract Commitment Details
- Event Timeline

## Acceptance Criteria
- Can create a `$1,000,000` PSP envelope.
- Raw amount is visible only in Mastercard/PSP private views, never on-chain.
- Contract stores commitment hash and metadata hash only.
