# Service Plan: Commitment Ledger, Smart Contracts, and Nullifiers

## Responsibility
Provide contract-facing APIs for commitments, receivable records, nullifier consumption, and settlement statement registration.

## Contracts
- `ProgramEnvelopeCommitment.sol`
- `BusinessAllocationCommitment.sol`
- `AgentBudgetCommitment.sol`
- `MerchantReceivableCommitment.sol`
- `NullifierRegistry.sol`
- `SettlementStatementRegistry.sol`

## Rules
- No actual amount on-chain.
- Store hashes, IDs, status, mandate references, and metadata hashes only.
- Nullifier consumption prevents duplicate merchant claims.
- Local demo may use deterministic hashes first; upgrade to ZK proof generation later.

## APIs

```http
POST /commitments/program-envelope
POST /commitments/business-allocation
POST /commitments/agent-budget
POST /commitments/merchant-receivable
POST /nullifiers/consume
GET /nullifiers/{nullifierHash}
POST /settlement-statements
```

## Acceptance Criteria
- Duplicate nullifier consumption fails.
- Contract status events are emitted.
- PSP monitor can see all status transitions.
