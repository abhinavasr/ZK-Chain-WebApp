# Service Plan: Eventing and Observability

## Responsibility
Provide a shared event backbone and queryable activity timeline for all portals.

## Local Tech Choice
Use Redpanda or NATS for event bus. Use Postgres for event query projection.

## Required Topics
- `funding.mastercard.envelope.created`
- `funding.psp.wallet.added`
- `funding.psp.business.allocated`
- `business.auth.otp.verified`
- `business.auth.passkey.registered`
- `mandate.intent.created`
- `mandate.budget.presented`
- `mandate.budget.signed`
- `activity.created`
- `activity.estimate.created`
- `x402.challenge.received`
- `x402.payment.asserted`
- `x402.payment.rejected`
- `merchant.capability.delivered`
- `merchant.receivable.created`
- `merchant.claim.initiated`
- `nullifier.consumed`
- `settlement.statement.generated`
- `contract.status.changed`

## Acceptance Criteria
- Every portal can show relevant timeline events.
- Every x402 challenge/assertion appears in observability.
- Contract status changes are queryable by PSP monitor.
