# Service Plan: Google Adverts Merchant Service and Portal

## Responsibility
Replace the previous OpenAI Text Generation merchant with a Google Adverts merchant that simulates launching a paid ad campaign.

## Capability
- ID: `ad-campaign-launch`
- Price: `$0.02` per API/capability call
- Function: accepts campaign copy/creative/context and returns simulated ad campaign ID/status.

## API Flow

```http
POST /capabilities/ad-campaign-launch
GET /campaigns/{campaignId}
```

Without assertion: return x402 challenge.  
With valid assertion: create simulated campaign record.

## Portal Screens
- Campaign Launch Requests
- x402 Challenges
- Assertions
- Delivered Campaigns
- Receivables
- Initiate Claim
- Settlement Statements

## Acceptance Criteria
- OpenAI Text Gen is not part of v2 merchant set.
- Google Adverts appears as the third independent merchant portal/service.
- Campaign launch result is included in final consumer summary.
