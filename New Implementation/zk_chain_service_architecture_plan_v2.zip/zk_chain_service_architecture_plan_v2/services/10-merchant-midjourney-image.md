# Service Plan: Midjourney Image Merchant Service and Portal

## Responsibility
Expose paid image-generation capability protected by x402 and support additional payment challenges if generation requires more usage than estimated.

## Capability
- ID: `image-generation`
- Base Price: `$0.50`
- Additional challenge: configurable, e.g. another `$0.50` if retry/upscale/extra token simulation is triggered.

## API Flow

```http
POST /capabilities/image-generation
POST /capabilities/image-generation/{jobId}/continue
GET /capabilities/image-generation/{jobId}
```

## Important Behavior
The Image Agent may receive more than one x402 challenge. Payment Orchestration must allow additional payment only while within approved budget threshold.

## Portal Screens
- Image Jobs
- Challenges Issued
- Assertions Received
- Receivables
- Claim Batches
- Settlement Statements

## Acceptance Criteria
- Can simulate an extra x402 challenge.
- Extra challenge is rejected by Payment Orchestration if budget exceeded.
- Receivable is created only for delivered paid steps.
