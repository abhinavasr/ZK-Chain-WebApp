# Service Plan: CNN News Merchant Service and Portal

## Responsibility
Expose a paid news/context capability protected by x402 and provide merchant receivable/claim visibility.

## Capability
- ID: `latest-news-search`
- Price: `$0.10`
- Example: latest context around football game in New Jersey and Mastercard partnership campaign.

## API Flow

```http
POST /capabilities/latest-news-search
```

Without assertion: return `402 Payment Required` challenge.  
With valid assertion: return simulated news/context response.

## Portal Screens
- Challenges Issued
- Assertions Received
- News Calls Delivered
- Receivables
- Initiate Claim
- Nullifier Status
- Settlement Statements

## Acceptance Criteria
- Returns x402 challenge for unpaid call.
- Verifies assertion before returning news content.
- Creates receivable commitment after delivery.
