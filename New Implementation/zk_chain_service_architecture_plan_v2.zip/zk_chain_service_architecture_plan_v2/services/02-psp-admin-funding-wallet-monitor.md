# Service Plan: PSP Admin, Funding, Wallet, and Contract Monitor

## Responsibility
Manage business funding allocations sourced from Mastercard envelope, PSP-owned wallets, or a mixed source. Continuously monitor contract, claim, and settlement status.

## Key Requirements
- PSP sees fixed Mastercard envelope and remaining capacity.
- PSP can allocate Mastercard-backed credit to many businesses as long as total allocation <= envelope.
- PSP can add separate blockchain wallet funds.
- PSP can fund businesses from Mastercard-backed credit, PSP wallet, or mixed source.
- PSP monitor watches smart contract status, nullifier consumption, merchant claims, and settlement statements.

## Services
- `psp-funding-service`
- `psp-wallet-service`
- `psp-contract-monitor-service` or monitor module inside PSP service

## APIs

```http
POST /business-allocations
GET /business-allocations
GET /business-allocations/{allocationId}
POST /wallets
POST /wallets/{walletId}/topups
GET /monitor/contracts
GET /monitor/claims
GET /monitor/settlements
```

## Validation Rules
- Reject Mastercard-backed allocation if it exceeds remaining envelope.
- Keep PSP wallet liquidity separate from Mastercard-backed line of credit.
- For mixed allocations, record source breakdown privately.

## Events Consumed
- `funding.mastercard.envelope.created`
- `merchant.claim.initiated`
- `nullifier.consumed`
- `settlement.statement.generated`
- `contract.status.changed`

## Events Produced
- `funding.psp.wallet.added`
- `funding.psp.business.allocated`

## Portal Screens
- Envelope Overview
- Business Allocation Wizard
- PSP Wallets
- Source Breakdown
- Smart Contract Monitor
- Merchant Claim Monitor
- Settlement Statements

## Acceptance Criteria
- Cannot allocate $1,000,001 from a $1,000,000 Mastercard envelope.
- Can add PSP-owned wallet funding independently.
- Contract monitor updates when merchant claims consume nullifiers.
