# Service Plan: Mandate Evidence Service

## Responsibility
Create, store, sign, verify, and expose AP2-style mandate evidence for the user’s campaign authorization.

## Mandates

### Intent Mandate
Captures the user’s high-level instruction:

```json
{
  "intent": "Run a campaign for Mastercard to showcase the partnership for upcoming Football game in New Jersey",
  "businessId": "agency-001",
  "userId": "user-001",
  "createdAt": "..."
}
```

### Budget / Checkout Mandate
Captures the user-approved budget:

```json
{
  "activityId": "act_001",
  "estimatedAmount": "0.62",
  "bufferPercent": 20,
  "approvedMaxAmount": "0.75",
  "currency": "USD",
  "allowedMerchants": ["cnn-news", "midjourney-image", "google-adverts"],
  "allowedCapabilities": ["latest-news-search", "image-generation", "ad-campaign-launch"],
  "expiry": "..."
}
```

### Payment Mandate
Derived from approved budget mandate and used by Payment Orchestration Service to create assertions.

## APIs

```http
POST /mandates/intent
POST /mandates/budget
POST /mandates/budget/{mandateId}/sign-passkey
POST /mandates/payment
GET /mandates/{mandateId}
POST /mandates/verify
```

## Acceptance Criteria
- Mandate hash is stored in commitment contract.
- Passkey approval is bound to activity ID and approved max budget.
- Payment Orchestration can verify mandate before paying x402 challenges.
