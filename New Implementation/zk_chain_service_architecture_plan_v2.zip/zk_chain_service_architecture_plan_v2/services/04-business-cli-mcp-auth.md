# Service Plan: Business CLI, MCP Server, OTP, and Passkey Authentication

## Responsibility
Provide the local machine-to-machine entry point used by Claude CLI or another MCP-compatible client. Handle browser-based login, OTP `1234`, passkey registration, and passkey approval.

## Components
- `business-cli`
- `business-cli-mcp-server`
- `business-auth-service`
- Browser auth pages

## CLI Commands

```bash
business-cli auth login
business-cli campaign run "Run a campaign for Mastercard to showcase the partnership for upcoming Football game in New Jersey"
business-cli campaign status <activityId>
business-cli campaign costs <activityId>
```

## MCP Tools

```json
[
  "business.authenticate",
  "campaign.estimate",
  "campaign.confirmBudget",
  "campaign.execute",
  "campaign.getCostSummary"
]
```

## Auth Flow
1. CLI detects missing session.
2. CLI opens browser auth URL.
3. User enters OTP `1234`.
4. Auth service verifies OTP.
5. User creates passkey through WebAuthn.
6. Auth service returns session token to CLI.
7. For budget approval, CLI opens browser approval page.
8. User signs with passkey.
9. Approval signature is bound to activity ID, amount cap, expiry, and allowed merchants.

## Acceptance Criteria
- OTP fixed value is `1234` for demo.
- Passkey is required for budget approval.
- CLI can be called by MCP client and also manually from terminal.
