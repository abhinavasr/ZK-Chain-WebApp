# Service Plan: Merchant Claims and Settlement

## Responsibility
Allow merchants to see total payable, initiate claims, consume nullifiers, and generate settlement statements.

## Claim Flow
1. Merchant portal shows unpaid receivables.
2. Merchant selects receivables or claim period.
3. Merchant Claim Service creates claim batch.
4. Claim Service calls Commitment Ledger to consume nullifiers.
5. If all nullifiers are valid, generate settlement statement.
6. Settlement statement hash is registered.
7. PSP monitor receives settlement event.

## APIs

```http
GET /merchants/{merchantId}/receivables
GET /merchants/{merchantId}/payable-total
POST /claims
GET /claims/{claimId}
POST /claims/{claimId}/submit-settlement
```

## Settlement Statement

```json
{
  "statementId": "stmt_...",
  "merchantId": "cnn-news",
  "pspId": "adyen-psp-demo",
  "periodStart": "...",
  "periodEnd": "...",
  "receivableCount": 3,
  "privateTotalAmount": "stored privately, not on-chain",
  "statementHash": "hash(statement)",
  "nullifierHashes": ["nul_..."],
  "status": "generated"
}
```

## Acceptance Criteria
- Merchant can see total payable.
- Merchant can initiate claim.
- Duplicate claim fails because nullifier is already consumed.
- PSP portal sees settlement statement status.
