# ZK Chain WebApp Service Architecture Plan v2

This pack updates the service architecture to include MCP Business CLI, AP2-style mandates, x402 merchant capability payments, PSP funding envelopes, merchant claims, nullifier settlement, and PSP smart contract monitoring.

Start with `00-master-service-architecture-plan.md`, then assign individual service files under `services/` to coding agents.
